export interface Matiere {
  id: number;
  nom: string;
  quantite: number;
  dateAjout: string;
}
