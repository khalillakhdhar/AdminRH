export interface Cours {
  id: number;
  titre: string;
  urlFichier: string;
  formationId: number;
}
