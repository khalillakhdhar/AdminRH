export interface Details {
}
